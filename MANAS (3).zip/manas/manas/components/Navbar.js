import React from "react";
import Link from "next/link";
import { VscAccount } from "react-icons/vsc";
import { BsFillChatDotsFill } from "react-icons/bs";

const Navbar = () => {
  return (
    <div>
      <div className="nav bg-indigo-50 ">
        <ul className="flex items-center space-x-3 font-bold md: text-sm text-3xl">
        <Link href={"/"}>
            <a className="flex title-font font-medium items-center md:justify-start justify-center text-gray-900">
              Manas
            </a>
          </Link>

          <Link href={"/about"}>
            <a>
              <li>About</li>
            </a>
          </Link>
          
          <Link href={"/contact"}>
            <a>
              <li>Contact</li>
            </a>
          </Link>
          
          <Link href={"/chats"}>
            <a>
              <li>Chat</li>
            </a>
          </Link>

          <Link href={"/shop"}>
            <a>
              <li>Shop</li>
            </a>
          </Link>

        </ul>
      </div>

      <div className="cart absolute right-0 top-2 mx-5 space-x-2">
        <button>
          <VscAccount className="text-2xl" />
        </button>
        <button>
          <BsFillChatDotsFill className="text-2xl" />
        </button>
      </div>
    </div>
  );
};

export default Navbar;

import React from 'react'

const chats = () => {
  return (
    <div>
      This is chats
    </div>
  )
}

export default chats

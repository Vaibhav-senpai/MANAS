import React from 'react'

const contact = () => {
  return (
    <div>
      This is contacting
    </div>
  )
}

export default contact

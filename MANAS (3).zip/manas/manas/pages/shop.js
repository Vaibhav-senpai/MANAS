import React from 'react'

const shop = () => {
  return (
    <div>
      This is shops
    </div>
  )
}

export default shop

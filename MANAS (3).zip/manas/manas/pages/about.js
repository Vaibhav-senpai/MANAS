import React from 'react'

const about = () => {
  return (
    <div>
      THis is abouts page
      
    </div>
  )
}

export default about
